import React from "react";
import { useCurrentFrame, useVideoConfig, interpolate, Easing } from "remotion";
import { getTheme } from "../../themes.js";

export const BigNumber = ({ data = {}, clipFrame = 0, theme = "blue_grid" }) => {
  const { fps } = useVideoConfig();
  const th = getTheme(theme);
  const accent = th.subtitle?.accent || "#3b82f6";
  const bg = th.subtitle?.bg || "rgba(6,12,36,0.92)";
  const border = th.subtitle?.border || accent;

  const value = data.value || "96%";
  const label = data.label || "";
  const context = data.context || "";
  const prefix = data.prefix || "";
  const suffix = data.suffix || "";

  // Slam in with bounce
  const scaleIn = interpolate(clipFrame, [0, fps * 0.25, fps * 0.35], [0.3, 1.08, 1.0], {
    extrapolateLeft: "clamp", extrapolateRight: "clamp",
    easing: Easing.out(Easing.cubic),
  });
  const opacity = interpolate(clipFrame, [0, fps * 0.1], [0, 1], { extrapolateRight: "clamp" });

  // Label slides up
  const labelY = interpolate(clipFrame, [fps * 0.15, fps * 0.4], [30, 0], {
    extrapolateLeft: "clamp", extrapolateRight: "clamp",
    easing: Easing.out(Easing.cubic),
  });
  const labelOp = interpolate(clipFrame, [fps * 0.15, fps * 0.45], [0, 1], {
    extrapolateLeft: "clamp", extrapolateRight: "clamp",
  });

  // Pulse glow on accent
  const glow = 0.7 + Math.sin(clipFrame / fps * 2) * 0.3;

  return (
    <div style={{
      position: "absolute", inset: 0, display: "flex",
      flexDirection: "column", alignItems: "center", justifyContent: "center",
      background: bg, opacity,
      padding: "0 60px", // side padding so nothing ever bleeds to edge
    }}>
      {/* Glow ring behind number */}
      <div style={{
        position: "absolute",
        width: 420, height: 420,
        borderRadius: "50%",
        background: `radial-gradient(ellipse, ${accent}22 0%, transparent 70%)`,
        transform: `scale(${glow})`,
        pointerEvents: "none",
      }} />

      {/* The number itself */}
      <div style={{
        transform: `scale(${scaleIn})`,
        display: "flex", alignItems: "baseline", gap: 4,
        lineHeight: 1,
        maxWidth: "100%",
      }}>
        {prefix && (
          <span style={{
            fontFamily: "sans-serif", fontWeight: 900,
            fontSize: 96, color: accent,
            textShadow: `0 0 40px ${accent}aa`,
            flexShrink: 0,
          }}>{prefix}</span>
        )}
        <span style={{
          fontFamily: "sans-serif", fontWeight: 900,
          fontSize: 180, color: "#ffffff",
          textShadow: `0 0 60px ${accent}66, 0 4px 0 rgba(0,0,0,0.5)`,
          letterSpacing: "-6px",
          // Scale down if value is long (e.g. "300,000")
          ...(String(value).length > 6 ? { fontSize: 130, letterSpacing: "-4px" } : {}),
          ...(String(value).length > 9 ? { fontSize: 90, letterSpacing: "-2px" } : {}),
        }}>{value}</span>
        {suffix && (
          <span style={{
            fontFamily: "sans-serif", fontWeight: 900,
            fontSize: 96, color: accent,
            textShadow: `0 0 40px ${accent}aa`,
            flexShrink: 0,
          }}>{suffix}</span>
        )}
      </div>

      {/* Label — fixed width, wraps cleanly, centered */}
      {label && (
        <div style={{
          transform: `translateY(${labelY}px)`,
          opacity: labelOp,
          marginTop: 20,
          padding: "10px 32px",
          background: `${accent}22`,
          border: `1px solid ${border}66`,
          borderRadius: 8,
          maxWidth: 860,         // never wider than 860px
          width: "fit-content",
          textAlign: "center",
        }}>
          <span style={{
            fontFamily: "sans-serif", fontWeight: 700,
            fontSize: 28, color: "#ffffff", textTransform: "uppercase",
            letterSpacing: 3,
            display: "block",
            lineHeight: 1.4,
            wordBreak: "break-word",
            whiteSpace: "normal",  // allow wrapping — prevents overflow
          }}>{label}</span>
        </div>
      )}

      {/* Context line — also capped width */}
      {context && (
        <div style={{
          opacity: labelOp, marginTop: 14,
          fontFamily: "sans-serif", fontWeight: 400,
          fontSize: 22, color: "rgba(255,255,255,0.6)",
          fontStyle: "italic",
          maxWidth: 860,
          textAlign: "center",
          lineHeight: 1.4,
          wordBreak: "break-word",
          whiteSpace: "normal",
        }}>{context}</div>
      )}
    </div>
  );
};
